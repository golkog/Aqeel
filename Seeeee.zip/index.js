/*
 * ==========================================================
 * ChatGPT Admin Workspace Automator - V9 (The Perfect Script)
 * ==========================================================
 * - تم تطبيق السكربت اليدوي الناجح 100% حرفياً (تخطي شاشة Empty Workspace).
 * - لا يوجد انتظار وهمي بعد الآن، فقط تنفيذ مباشر وسريع.
 * - نظام المساحات (الأعضاء + تغيير الاسم) يعمل بامتياز.
 * ==========================================================
 */

const TelegramBot = require('node-telegram-bot-api');
const { chromium } = require('playwright-extra');
const stealth = require('puppeteer-extra-plugin-stealth')();
const fs = require('fs');
const path = require('path');

chromium.use(stealth);

const BOT_TOKEN = process.env.BOT_TOKEN || 'ضع_توكن_البوت_هنا_إذا_لم_يكن_في_البيئة';
if (!BOT_TOKEN || BOT_TOKEN === 'ضع_توكن_البوت_هنا_إذا_لم_يكن_في_البيئة') {
    console.error("❌ خطأ: BOT_TOKEN مفقود.");
    process.exit(1);
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const sessions = {};
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// ================= نظام توليد السكربت (للوضع اليدوي) =================
class PlaywrightCodeGenerator {
    constructor() { this.codeLines = []; this.stepCounter = 1; }
    addStep(comment) { this.codeLines.push(`\n    // === الخطوة ${this.stepCounter}: ${comment} ===`); this.stepCounter++; }
    addCommand(cmd) { this.codeLines.push(`    ${cmd}`); console.log(`[Generated Code]: ${cmd}`); }
    getFinalScript() { return `// ==========================================\n// 🤖 سكربت Playwright\n// ==========================================\nconst { chromium } = require('playwright');\n(async () => {\n    const browser = await chromium.launch({ headless: false });\n    const context = await browser.newContext({ viewport: { width: 1366, height: 768 } });\n    const page = await context.newPage();\n${this.codeLines.join('\n')}\n})();`; }
}

// ================= دوال التحكم التفاعلي =================
const GRID_COLS = 45; const GRID_ROWS = 25; const TOTAL_CELLS = GRID_COLS * GRID_ROWS; 
async function drawGridAndScreenshot(page, chatId, caption) {
    const p = path.join(__dirname, `grid_${Date.now()}.png`);
    try {
        await page.screenshot({ path: p, fullPage: false });
        let canvasModule; try { canvasModule = require('canvas'); } catch (e) { await bot.sendMessage(chatId, "⚠️ يرجى تثبيت canvas."); return; }
        const { createCanvas, loadImage } = canvasModule;
        const img = await loadImage(p); const canvas = createCanvas(img.width, img.height); const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0); const cellW = img.width / GRID_COLS; const cellH = img.height / GRID_ROWS;
        for (let row = 0; row < GRID_ROWS; row++) {
            for (let col = 0; col < GRID_COLS; col++) {
                const i = row * GRID_COLS + col; const x = col * cellW; const y = row * cellH;
                ctx.strokeStyle = 'rgba(255,255,0,0.3)'; ctx.strokeRect(x, y, cellW, cellH);
                ctx.fillStyle = 'rgba(255, 255, 255, 0.7)'; ctx.font = 'bold 9px Sans'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
                ctx.strokeText(String(i), x + cellW/2, y + cellH/2); ctx.fillText(String(i), x + cellW/2, y + cellH/2);
            }
        }
        fs.writeFileSync(p, canvas.toBuffer('image/png'));
        await bot.sendPhoto(chatId, p, { caption: caption, parse_mode: 'Markdown' });
    } catch (error) {} finally { if (fs.existsSync(p)) fs.unlinkSync(p); }
}

async function drawRedDot(page, x, y) {
    await page.evaluate((pos) => {
        let dot = document.getElementById('bot-red-dot');
        if (!dot) { dot = document.createElement('div'); dot.id = 'bot-red-dot'; dot.style.cssText = 'position:fixed;width:14px;height:14px;background-color:red;border:2px solid white;border-radius:50%;z-index:9999999;pointer-events:none;box-shadow:0 0 5px #000;transform:translate(-50%, -50%);'; document.body.appendChild(dot); }
        dot.style.left = pos.x + 'px'; dot.style.top = pos.y + 'px';
    }, {x, y});
}
async function removeRedDot(page) { await page.evaluate(() => { const dot = document.getElementById('bot-red-dot'); if (dot) dot.remove(); }); }

async function sendInteractiveMenu(chatId, text = "🎮 **أنت الآن تتحكم بالمتصفح:**") {
    const opts = { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [
        [{ text: '🌐 فتح رابط', callback_data: 'int_goto_url' }, { text: '📸 تحديث الشاشة', callback_data: 'int_refresh' }],
        [{ text: '🔍 البحث عن نص/زر والضغط عليه', callback_data: 'int_search_text' }],
        [{ text: '🖱️ التحكم بالماوس', callback_data: 'int_show_grid' }, { text: '🔴 كليك', callback_data: 'int_click_mouse' }],
        [{ text: '⌨️ كتابة نص', callback_data: 'int_type_text' }, { text: '↩️ انتر', callback_data: 'int_press_enter' }],
        [{ text: '🔐 استخراج كود 2FA', callback_data: 'int_fetch_2fa' }],
        [{ text: '✅ إنهاء التسجيل اليدوي والمتابعة', callback_data: 'int_finish_login' }]
    ]}}; await bot.sendMessage(chatId, text, opts);
}

// ================= القائمة الرئيسية =================
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    if (!sessions[chatId]) sessions[chatId] = { step: null };
    bot.sendMessage(chatId, "مرحبا، اختر العملية للبدء:", {
        reply_markup: {
            inline_keyboard: [
                [{ text: 'اضافة مساحة (تلقائي سريع ⚡)', callback_data: 'add_workspace_auto' }],
                [{ text: 'اضافة مساحة (يدوي لتسجيل السكربت ✍️)', callback_data: 'add_workspace_manual' }]
            ]
        }
    });
});

// ================= معالجة الأزرار =================
bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    bot.answerCallbackQuery(query.id).catch(() => {});
    if (!sessions[chatId]) sessions[chatId] = { step: null };
    const state = sessions[chatId];

    if (query.data === 'add_workspace_auto' || query.data === 'add_workspace_manual') {
        state.mode = query.data === 'add_workspace_auto' ? 'auto' : 'manual';
        state.step = 'awaiting_credentials';
        const msgText = `قم بأرسال الايميل والباسورد ورمز المصادقة\nبعد ارسالهم بهذا الشكل:\n\n\nciig1414@synotynx.cfd\n0A0C0000zzzA https://2fa.fb.tools/MGDNQJR55XAU3NKA3HUMTBXQBNG6PTXQ`;
        bot.sendMessage(chatId, msgText);
    } 

    else if (query.data.startsWith('int_')) {
        const action = query.data.replace('int_', '');
        if (!state.isInteractive || !state.page) return bot.sendMessage(chatId, "⚠️ لا توجد جلسة يدوية نشطة.");

        if (action === 'refresh') {
            const p = path.join(__dirname, `refresh_${Date.now()}.png`);
            await state.page.screenshot({ path: p }); await bot.sendPhoto(chatId, p); fs.unlinkSync(p);
            await sendInteractiveMenu(chatId);
        }
        else if (action === 'goto_url') { bot.sendMessage(chatId, "🌐 أرسل **الرابط**:"); state.step = 'int_awaiting_goto_url'; }
        else if (action === 'search_text') { bot.sendMessage(chatId, "🔍 أرسل **الكلمة/النص** للضغط عليه:"); state.step = 'int_awaiting_search_text'; }
        else if (action === 'type_text') { bot.sendMessage(chatId, "⌨️ أرسل **النص**:"); state.step = 'int_awaiting_type_text'; }
        else if (action === 'press_enter') {
            state.codeGen.addStep("الضغط على Enter"); state.codeGen.addCommand(`await page.keyboard.press('Enter');`);
            await state.page.keyboard.press('Enter'); await sleep(1500); bot.sendMessage(chatId, "↩️ تم الضغط."); await sendInteractiveMenu(chatId);
        }
        else if (action === 'show_grid') { await drawGridAndScreenshot(state.page, chatId, `👁️ **المربعات:**`); bot.sendMessage(chatId, `🧭 أرسل **رقم المربع**:`); state.step = 'int_awaiting_move_mouse'; }
        else if (action === 'click_mouse') {
            if (state.mouseX !== undefined) {
                state.codeGen.addStep(`كليك X=${state.mouseX}, Y=${state.mouseY}`); state.codeGen.addCommand(`await page.mouse.click(${state.mouseX}, ${state.mouseY});`);
                await state.page.mouse.click(state.mouseX, state.mouseY); await sleep(1500); bot.sendMessage(chatId, `🔴 تم الضغط!`);
            } else bot.sendMessage(chatId, "⚠️ حدد مربع أولاً.");
            await sendInteractiveMenu(chatId);
        }
        else if (action === 'fetch_2fa') {
            try {
                bot.sendMessage(chatId, "⏳ جاري استخراج كود الـ 2FA...");
                state.codeGen.addStep("استخراج 2FA وكتابته");
                const mfaPage = await state.context.newPage(); await mfaPage.goto(state.url2fa, { waitUntil: "domcontentloaded", timeout: 30000 }); await sleep(3000);
                const codeMatch = (await mfaPage.innerText('body')).match(/\b\d{3}\s*\d{3}\b/) || (await mfaPage.innerText('body')).match(/\b\d{6}\b/);
                if (codeMatch) {
                    const code6 = codeMatch[0].replace(/\s+/g, ''); await mfaPage.close(); await state.page.bringToFront();
                    state.codeGen.addCommand(`await page.keyboard.type("${code6}", { delay: 50 });`);
                    await state.page.keyboard.type(code6, { delay: 50 }); bot.sendMessage(chatId, `✅ تم كتابة: ${code6}`);
                } else bot.sendMessage(chatId, "❌ تعذر العثور على الكود.");
            } catch(e) { bot.sendMessage(chatId, `❌ خطأ: ${e.message}`); }
            await sendInteractiveMenu(chatId);
        }
        else if (action === 'finish_login') {
            state.isInteractive = false;
            bot.sendMessage(chatId, "✅ جاري استخراج السكربت والمتابعة...");
            const logPath = path.join(__dirname, `Script_${Date.now()}.js`); fs.writeFileSync(logPath, state.codeGen.getFinalScript());
            await bot.sendDocument(chatId, logPath, { caption: "🧑‍💻 **سكربتك جاهز!**", parse_mode: 'Markdown' }); fs.unlinkSync(logPath);
            
            bot.sendMessage(chatId, "🚀 جاري التوجه لصفحة الأعضاء (الرجاء الانتظار قليلاً)...");
            try {
                await state.page.goto("https://chatgpt.com/admin/members", { waitUntil: "domcontentloaded", timeout: 45000 }); await sleep(6000);
                const p = path.join(__dirname, `admin_${Date.now()}.png`); await state.page.screenshot({ path: p });
                await bot.sendPhoto(chatId, p, { caption: "ماذا حدث", reply_markup: { inline_keyboard: [[{ text: 'اضافة شخص', callback_data: 'add_person' }]] }});
                fs.unlinkSync(p);
            } catch (err) { bot.sendMessage(chatId, `❌ خطأ: ${err.message}`); }
        }
    }

    // --- أزرار سير العمل (المساحات) ---
    else if (query.data === 'add_person') {
        if (!state.page) return bot.sendMessage(chatId, "⚠️ الجلسة منتهية.");
        try {
            await bot.sendMessage(chatId, "⏳ جاري فتح نافذة الدعوة...");
            const inviteBtn = state.page.locator('button:has-text("Invite member"), button:has-text("Invite members")').first();
            await inviteBtn.waitFor({ state: 'visible', timeout: 15000 }).catch(()=>{}); await inviteBtn.click({ force: true }); await sleep(2000);
            const emailInput = state.page.locator('input[type="email"], textarea[placeholder*="email" i], input[placeholder*="email" i]').first();
            await emailInput.waitFor({ state: 'visible', timeout: 5000 }).catch(()=>{}); await emailInput.click({ force: true });
            state.step = 'awaiting_invite_email'; bot.sendMessage(chatId, "يجب ارسال الايميل");
        } catch (error) { bot.sendMessage(chatId, `❌ خطأ: ${error.message}`); }
    }
    else if (query.data === 'change_ws_name') {
        if (!state.page) return bot.sendMessage(chatId, "⚠️ الجلسة منتهية.");
        try {
            await bot.sendMessage(chatId, "⏳ جاري التوجه للإعدادات...");
            await state.page.goto('https://chatgpt.com/admin', { waitUntil: 'domcontentloaded' }); await sleep(4000);
            const nameInput = state.page.locator('input[type="text"]').first();
            await nameInput.waitFor({ state: 'visible', timeout: 10000 }).catch(()=>{}); await nameInput.click({ force: true });
            await state.page.keyboard.press('ControlOrMeta+A'); await state.page.keyboard.press('Backspace'); 
            state.step = 'awaiting_new_ws_name'; bot.sendMessage(chatId, "ادخل الاسم الجديد");
        } catch (error) { bot.sendMessage(chatId, `❌ خطأ: ${error.message}`); }
    }
});

// ================= معالجة النصوص =================
bot.on('message', async (msg) => {
    const chatId = msg.chat.id; const text = msg.text?.trim();
    if (!text || text.startsWith('/')) return;
    if (!sessions[chatId]) sessions[chatId] = { step: null }; const state = sessions[chatId];

    // ----- أوامر التحكم اليدوي -----
    if (state.isInteractive) {
        if (state.step === 'int_awaiting_goto_url') {
            state.step = null; let url = text.startsWith('http') ? text : 'https://' + text;
            state.codeGen.addStep(`التوجه إلى: ${url}`); state.codeGen.addCommand(`await page.goto("${url}", { waitUntil: "domcontentloaded" });`);
            try { await state.page.goto(url, { waitUntil: "domcontentloaded", timeout: 60000 }); await sleep(3000); bot.sendMessage(chatId, `✅ تم.`); } catch(e) { bot.sendMessage(chatId, `❌ فشل`); } 
            await sendInteractiveMenu(chatId); return;
        }
        else if (state.step === 'int_awaiting_search_text') {
            state.step = null; const safeText = text.replace(/"/g, '\\"').replace(/'/g, "\\'");
            try { 
                const loc = state.page.locator(`text="${text}"`).first(); 
                if (await loc.isVisible({ timeout: 5000 }).catch(()=>false)) { 
                    state.codeGen.addStep(`الضغط على "${text}"`); state.codeGen.addCommand(`await page.locator('text="${safeText}"').first().click({ force: true });`);
                    await loc.click({ force: true }); await sleep(1500); bot.sendMessage(chatId, `🎯 تم.`); 
                } else bot.sendMessage(chatId, `❌ لم أعثر عليه.`); 
            } catch(e) { bot.sendMessage(chatId, `❌ خطأ: ${e.message}`); } 
            await sendInteractiveMenu(chatId); return;
        }
        else if (state.step === 'int_awaiting_type_text') {
            state.step = null; state.codeGen.addStep(`كتابة: ${text}`); state.codeGen.addCommand(`await page.keyboard.type("${text.replace(/"/g, '\\"')}", { delay: 50 });`);
            await state.page.keyboard.type(text, { delay: 50 }); await sleep(1000); bot.sendMessage(chatId, `⌨️ تمت الكتابة.`); await sendInteractiveMenu(chatId); return;
        }
        else if (state.step === 'int_awaiting_move_mouse') {
            state.step = null; const num = parseInt(text);
            if (!isNaN(num) && num >= 0 && num < TOTAL_CELLS) {
                const vw = 1366 / GRID_COLS; const vh = 768 / GRID_ROWS; const col = num % GRID_COLS; const row = Math.floor(num / GRID_COLS);
                state.mouseX = parseFloat(((col * vw) + (vw / 2)).toFixed(2)); state.mouseY = parseFloat(((row * vh) + (vh / 2)).toFixed(2));
                await state.page.mouse.move(state.mouseX, state.mouseY); await sendInteractiveMenu(chatId, `🔴 الماوس فوق المربع [${num}]، اضغط كليك للتأكيد.`);
            } else bot.sendMessage(chatId, `❌ رقم خطأ.`); return;
        }
    }

    // ----- خطوة 1: بدء تسجيل الدخول التلقائي -----
    if (state.step === 'awaiting_credentials') {
        const lines = text.split('\n').map(l => l.trim()).filter(l => l !== '');
        if (lines.length < 2) return bot.sendMessage(chatId, "⚠️ التنسيق غير صحيح.");

        state.email = lines[0];
        const parts = lines[1].split(' ');
        state.password = parts[0];
        state.url2fa = parts.find(p => p.includes('http'));

        state.step = 'processing';
        try {
            if (state.context) await state.context.close().catch(()=>{});
            const tempDir = fs.mkdtempSync(path.join(__dirname, 'cg_wrk_'));
            const context = await chromium.launchPersistentContext(tempDir, {
                headless: true, // لمراقبة المتصفح يعرض أمامك اجعله false
                args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-blink-features=AutomationControlled'],
                viewport: { width: 1366, height: 768 }
            });
            state.context = context; state.page = await context.newPage(); state.codeGen = new PlaywrightCodeGenerator();

            if (state.mode === 'manual') {
                state.isInteractive = true;
                await bot.sendMessage(chatId, `🛠️ **الوضع اليدوي!**\nالايميل: \`${state.email}\`\nالباسورد: \`${state.password}\``, {parse_mode: 'Markdown'});
                await state.page.goto("https://chatgpt.com/auth/login", { waitUntil: "domcontentloaded", timeout: 60000 });
                await sendInteractiveMenu(chatId); return;
            }

            // ========================================================
            // 🌟 الدخول التلقائي المبني على سكربت المستخدم حرفياً 🌟
            // ========================================================
            let statusMsg = await bot.sendMessage(chatId, "⏳ جاري تنفيذ مسار الدخول الدقيق الخاص بك...");
            const updateStatus = async (stepText) => { try { await bot.editMessageText(`⚡ ${stepText}`, { chat_id: chatId, message_id: statusMsg.message_id }); } catch(e){} };

            try {
                // 1. فتح الصفحة الأساسية
                await updateStatus("1/7 فتح صفحة الدخول...");
                await state.page.goto("https://chatgpt.com/auth/login", { waitUntil: "domcontentloaded", timeout: 60000 });
                await sleep(4000);
                
                // الخطوة 1: الضغط على "Log in"
                const loginBtn = state.page.locator('text="Log in"').first();
                if (await loginBtn.isVisible().catch(()=>false)) await loginBtn.click({ force: true });
                await sleep(2000);

                // الخطوة 2 و 3: كتابة الإيميل وانتر
                await updateStatus("2/7 كتابة الإيميل...");
                await state.page.keyboard.type(state.email, { delay: 50 });
                await sleep(500);
                await state.page.keyboard.press('Enter');

                // الخطوة 4 و 5: كتابة الباسورد وانتر
                await updateStatus("3/7 كتابة الباسورد...");
                await sleep(5000); 
                await state.page.keyboard.type(state.password, { delay: 50 });
                await sleep(500);
                await state.page.keyboard.press('Enter');

                // استخراج 2FA
                await updateStatus("4/7 جاري جلب كود 2FA...");
                const mfaPage = await context.newPage();
                await mfaPage.goto(state.url2fa, { waitUntil: "domcontentloaded", timeout: 30000 });
                await sleep(3000);
                const mfaText = await mfaPage.innerText('body');
                const codeMatch = mfaText.match(/\b\d{3}\s*\d{3}\b/) || mfaText.match(/\b\d{6}\b/);
                if (!codeMatch) throw new Error("لم يتم العثور على الكود في الرابط");
                const code6 = codeMatch[0].replace(/\s+/g, '');
                await mfaPage.close(); 
                await state.page.bringToFront();

                // الخطوة 6 و 7: إدخال الكود وانتر
                await updateStatus(`5/7 إدخال الكود (${code6})...`);
                await sleep(4000);
                await state.page.keyboard.type(code6, { delay: 50 });
                await sleep(500);
                await state.page.keyboard.press('Enter');

                // ==========================================================
                // 🚀 الخطوات 8، 9، 10: تخطي شاشة المساحة الجديدة
                // ==========================================================
                await updateStatus("6/7 تخطي إعدادات المساحة (Start as empty workspace)...");
                await sleep(5000); // ننتظر لتظهر نافذة الإعدادات

                // الخطوة 8: كليك في إحداثيات (561.58, 230.4) كما طلبت
                try { await state.page.mouse.click(561.58, 230.4); } catch(e){}
                await sleep(1000);

                // الخطوة 9: الضغط على "Start as empty workspace"
                try {
                    const emptyWsBtn = state.page.locator('text="Start as empty workspace"').first();
                    if (await emptyWsBtn.isVisible({ timeout: 5000 })) await emptyWsBtn.click({ force: true });
                } catch(e){}
                await sleep(1000);

                // الخطوة 10: الضغط على "Continue"
                try {
                    const contBtn = state.page.locator('text="Continue"').last(); // استخدام last() للضغط على كونتينيو الأخيرة إن وجدت عدة أزرار
                    if (await contBtn.isVisible({ timeout: 5000 })) await contBtn.click({ force: true });
                } catch(e){}
                await sleep(3000);
                // ==========================================================

                // الخطوة 11: التوجه لصفحة الأعضاء والتقاط الصورة
                await updateStatus("7/7 ✅ ناجح! التوجه لصفحة الأعضاء...");
                await state.page.goto("https://chatgpt.com/admin/members", { waitUntil: "domcontentloaded", timeout: 45000 });
                await sleep(6000);

                await bot.deleteMessage(chatId, statusMsg.message_id).catch(()=>{});
                const p = path.join(__dirname, `admin_${Date.now()}.png`);
                await state.page.screenshot({ path: p });
                await bot.sendPhoto(chatId, p, { caption: "ماذا حدث", reply_markup: { inline_keyboard: [[{ text: 'اضافة شخص', callback_data: 'add_person' }]] }});
                fs.unlinkSync(p);

            } catch (autoError) {
                await bot.deleteMessage(chatId, statusMsg.message_id).catch(()=>{});
                await bot.sendMessage(chatId, `⚠️ **فشل الدخول التلقائي!**\nالسبب: ${autoError.message}\n\n🚨 **تم تحويلك للتحكم اليدوي:** استكمل الدخول واستخدم الأزرار.\n\nالايميل: \`${state.email}\`\nالباسورد: \`${state.password}\`` , {parse_mode: 'Markdown'});
                state.isInteractive = true;
                const errPath = path.join(__dirname, `error_${Date.now()}.png`); await state.page.screenshot({ path: errPath });
                await bot.sendPhoto(chatId, errPath, { caption: "📸 لقطة لحظة التوقف:" }); fs.unlinkSync(errPath);
                await sendInteractiveMenu(chatId);
            }
        } catch (error) { bot.sendMessage(chatId, `❌ خطأ فادح: ${error.message}`); }
    }
    
    // ----- خطوة 2: إرسال الدعوة -----
    else if (state.step === 'awaiting_invite_email') {
        state.step = 'processing';
        let statusMsg = await bot.sendMessage(chatId, "⏳ جاري إرسال الدعوة...");
        try {
            await state.page.keyboard.type(text, { delay: 50 }); await sleep(1000);
            const sendBtn = state.page.locator('button:has-text("Send invites"), button:has-text("Send invite")').first();
            await sendBtn.click({ force: true }); await sleep(4000);
            await state.page.goto('https://chatgpt.com/admin', { waitUntil: 'domcontentloaded' }); await sleep(5000);
            
            let wsName = "غير معروف";
            const nameInput = state.page.locator('input[type="text"]').first();
            if (await nameInput.isVisible()) { wsName = await nameInput.inputValue(); }
            
            const p = path.join(__dirname, `invite_${Date.now()}.png`); await state.page.screenshot({ path: p });
            await bot.deleteMessage(chatId, statusMsg.message_id).catch(()=>{});
            await bot.sendPhoto(chatId, p, { caption: `تم ارسال الدعوة\nWorkspace name                                       ${wsName}`, reply_markup: { inline_keyboard: [[{ text: 'تغيير اسم المساحة', callback_data: 'change_ws_name' }]] }});
            fs.unlinkSync(p);
        } catch (error) { bot.sendMessage(chatId, `❌ خطأ: ${error.message}`); }
    }
    
    // ----- خطوة 3: تغيير اسم المساحة -----
    else if (state.step === 'awaiting_new_ws_name') {
        state.step = 'processing';
        try {
            await state.page.keyboard.type(text, { delay: 50 }); await sleep(1000);
            const saveBtn = state.page.locator('button:has-text("Save")').first();
            if (await saveBtn.isVisible().catch(()=>false)) { await saveBtn.click({ force: true }); } 
            else { await state.page.keyboard.press('Enter'); }
            await sleep(3000);
            bot.sendMessage(chatId, "تم وضع الاسم الجديد ثم Save");
        } catch (error) { bot.sendMessage(chatId, `❌ خطأ: ${error.message}`); }
    }
});

process.on('uncaughtException', (err) => {});
process.on('unhandledRejection', (reason) => {});

console.log("🤖 البوت يعمل الآن بالتحديث V9 (تخطي شاشة Empty Workspace بنجاح)...");
